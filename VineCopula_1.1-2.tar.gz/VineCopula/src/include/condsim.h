#if !defined(CONDSIM_H)
#define CONDSIM_H

// File condsim.c
void condsim(int* n, int* d, int* d1, double* u1, int* family, double* par, double* nu, double* out);

#endif
